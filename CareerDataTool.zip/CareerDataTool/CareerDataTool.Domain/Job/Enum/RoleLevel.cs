﻿namespace CareerDataTool.Domain.Job.Enum
{
    public enum RoleLevel
    {
        Junior = 0,
        Pleno = 1,
        Senior = 2,
        Especialista = 3,
        Lead = 4,
        Estagiario = 5
    }
}
