﻿namespace CareerDataTool.Domain.Job.Enum
{
    public enum Role
    {
        Desenvolvedor = 0,
        Analista = 1,
        Gerente = 2,
        Coordernador = 3,
        Lider = 4,
        Arquiteto = 5,
        Principal = 6,
        Coach = 7
    }
}
