﻿namespace CareerDataTool.Domain.Job.Enum
{
    public enum WorkMode
    {
        remoto = 0,
        hibrido = 1,
        presencial = 2
    }
}
