﻿namespace CareerDataTool.Domain.Enum
{
    public enum Language
    {
        PT_BR = 0,
        EN_US = 1,
        ES_ES = 2
    }
}
