﻿namespace CareerDataTool.Domain.Location
{
    public class Country
    {
        public int CountryId { get; set; }
        public string Name { get; set; }
        public List<State> States { get; set; }
    }
}
